﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebApplication
{
    /// <summary>
    /// Summary description for WsApiexamen
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WsApiexamen : System.Web.Services.WebService
    {
        Functions sql = new Functions();
        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }
        [WebMethod]
        public DataTable AgregarExamen(int id, string nombre, string descripcion)
        {
            DataTable dtresult = new DataTable { TableName = "TableName" };
            string q = "exec spAgregar " + id + ",'" + nombre + "','" + descripcion + "'";
            dtresult = sql.GetDataTable(q, "EricssonConn");
            return dtresult;
        }
        [WebMethod]
        public DataTable ActualizarExamen(int id, string nombre, string descripcion)
        {
            DataTable dtresult = new DataTable { TableName = "TableName" };
            string q = "exec spActualizar " + id + ",'" + nombre + "','" + descripcion + "'";
            dtresult = sql.GetDataTable(q, "EricssonConn");
            return dtresult;
        }
        [WebMethod]
        public DataTable EliminarExamen(int id)
        {
            DataTable dtresult = new DataTable { TableName = "TableName" };
            string q = "exec spEliminar " + id;
            dtresult = sql.GetDataTable(q, "EricssonConn");
            return dtresult;
        }
        [WebMethod]
        public DataTable ConsultarExamen(string nombre, string descripcion)
        {
            DataTable dtresult = new DataTable { TableName = "TableName" };
            string q = "exec spConsultar '" + nombre + "','" + descripcion + "'";
            dtresult = sql.GetDataTable(q, "EricssonConn");
            return dtresult;
        }

    }

    public class Functions
    {
        public DataTable GetDataTable(string sqlStatement, string cx)
        {
            // Create a new Sql Connection and set connection string accordingly
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString = ConfigurationManager.ConnectionStrings[cx].ConnectionString;
            sqlConnection.Open();
            // Create a SqlDataAdapter to get the results as DataTable
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlStatement, sqlConnection);
            sqlDataAdapter.SelectCommand.CommandTimeout = 720;
            // Create a new DataTable
            DataTable dtResult = new DataTable();
            // Fill the DataTable with the result of the SQL statement
            try
            {
                sqlDataAdapter.Fill(dtResult);
                return dtResult;
            }
            catch (System.Exception e)
            {
                DataColumn FirstNameColumn = new DataColumn();
                FirstNameColumn.DataType = System.Type.GetType("System.String");
                FirstNameColumn.ColumnName = "Error";

                dtResult.Columns.Add(FirstNameColumn);
                DataRow row;
                row = dtResult.NewRow();
                row["Error"] = e.Message.Replace("'", "-").Replace(";", "-");
                dtResult.Rows.Add(row);

                return dtResult;
            }
            finally
            {
                sqlConnection.Close();
            }
        }
    }

}
